import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppSettings } from './../../common/config/appsettings';
import { CommonUtil } from './../../common/utils/common.util';
@Injectable()
export class OwnershipService {
    public params: any;

    constructor(private http: Http) {
    }

    public getGCIDCIFData(searchValue: any): Observable<any> {
        const urlToGetCifId = AppSettings.apiBaseUrl + AppSettings.apiToGetCifId;
        const params: URLSearchParams = new URLSearchParams();
        const filter = { 'order': 'gcin' };
        params.set('access_token', null);
        params.set('filter', JSON.stringify(filter));
        const bodyData = { 'searchKeyword': searchValue };
        return this.http.post(urlToGetCifId, bodyData, { search: params })
            .map(
                res => res.json()
            ).catch(error => CommonUtil.errorResponseFunction(error));
    }

    addOwnership(item: any): Observable<any> {
        const urlToPostOwnership = AppSettings.apiBaseUrl + AppSettings.apiCollateralCustomer;
        const customer = {
            'entityId': item.cifId,
            'entityType': 'C',
            'entityName': item.name
        };
        return this.http.post(urlToPostOwnership, customer)
            .map(onSuccessSuccess.bind(this))
            .catch(error => CommonUtil.errorResponseFunction(error));
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }
}