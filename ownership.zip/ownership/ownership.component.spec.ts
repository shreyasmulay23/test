import { OwnershipTotalPercentageValidator } from './ownership-total-percentage-validator';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OwnershipComponent } from './ownership.component';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, SimpleChanges } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { IntlModule } from '@progress/kendo-angular-intl';
import { CommonUIModule } from '../../common/commonUI.module';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { Observable } from 'rxjs/Rx';
import { Collateral, OwnerShipList } from '../../collateral/model/collateral';
import { OwnershipService } from './ownership.service';
import { CollateralService } from '../collateral.service';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { AbstractControl } from '@angular/forms/src/model';
import { TabModelHelper } from 'app/common/tabbed-wizard/tabsModelHelper';
import { TabStatus } from 'app/common/models/TabStatus';
import { DataGridModule } from 'app/common/data-grid/data-grid.module';
export class OwnershipItemModel extends OwnerShipList {
    actualCFID = '';
    source = 'BACK_END';
}
class MockOwnershipService {
    addOwnership(ownershipFormValue: any) {
        return Observable.of(null);
    }

    getGCIDCIFData(data: any) {
        if (data.length > 3) {
            const sampleResponse: any = [{
                description: 'ABCD COMPANY OF INDIA (CFID_1)',
                gcin: 'CFID_1',
                type: 'COUNTERPARTY',
                typeDescription: 'COUNTERPARTY'
            }];
            return Observable.of(sampleResponse);
        } else {
            return Observable.throw({ status: 404 });
        }
    }
}
class MockCollateralService {
    tabList: any = TabModelHelper.data;

    getCollateral() {
        return new Collateral();
    }

    setStatusOfComponent(componentName: String, tabStatus: any) {
        // Change to set status in config file
        this.tabList.forEach(element => {
            if (element.id === componentName) {
                element.fullfillmentStyle = tabStatus;
            }
        });
    }
    createErrorTabs(tabId:string){
    }
}
class MockFormBuilder extends FormBuilder {
    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formBuilderGroup = formBuilder.group({
            cifId: ['', [Validators.required]],
            idType: ['', [Validators.required]],
            collateralOwnerShipPcnt: ['', [Validators.required]],
            name: ['', [Validators.required]],
            actualCFID: ['', [Validators.required]]
        });
        return formBuilderGroup;
    }

    getAddForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formBuilderGroup: FormGroup = formBuilder.group({
            cifId: ['CFID_1 ABCD COMPANY OF INDIA', [Validators.required]],
            idType: ['COUNTERPARTY', [Validators.required]],
            collateralOwnerShipPcnt: [30, [Validators.required]],
            name: ['ABCD COMPANY OF INDIA', [Validators.required]],
            actualCFID: ['CFID_1', [Validators.required]]
        });
        return formBuilderGroup;
    }

    setOwnershipForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formBuilderGroup: FormGroup = formBuilder.group({
            ownershipid: ['', [Validators.required]]
        });
        formBuilderGroup.addControl('totalPercentageSum', new FormControl('', []));
        return formBuilderGroup;
    }
}
class Helper {
    getRandomValue(arg: number): number {
        let flg = true;
        while (flg) {
            const tmpNum = Math.floor((Math.random() * 100) + 1);
            if (tmpNum !== arg) {
                flg = false;
                return tmpNum;
            }
        }
    }
}
describe('OwnershipComponent', () => {
    let component: OwnershipComponent;
    let fixture: ComponentFixture<OwnershipComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpModule,
                ButtonsModule, IntlModule, ClsSharedCommonModule,
                DropDownsModule, GridModule, CommonUIModule, PopupDialogModule, DataGridModule],
            declarations: [OwnershipComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [{ provide: CollateralService, useClass: MockCollateralService },
                { provide: OwnershipService, useClass: MockOwnershipService },
                { provide: FormBuilder, useClass: MockFormBuilder }]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(OwnershipComponent);
        component = fixture.componentInstance;
        component.ownershipForm = new FormGroup({});
        component.ownershipForm.addControl('totalPercentageSum', new FormControl('', []));
        component.ownershipItemForm = null;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('Popup Dialog should be disabled',
        async(() => {
            expect(component.showPopupDialog).toBe(false);
        }));
    it('Popup Dialog box should open onclick of ADD Ownership button', async(() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        component.showPopupDialog = false;
        component.ownershipItemForm = null;  // blank up the form to be added
        component.showAddOwnershipDialog();
        expect(component.showPopupDialog).toBe(true);
        expect(component.ownershipItemForm).toBeDefined();
    }));
    it('Should show normalgrid on init', async(() => {
        component.showSummaryGrid = false;
        component.customizeOwnershipGridForSummaryComp();
        if (component.showSummaryGrid) {
            expect(component.divForNormalGrid).toBe(false);
        } else {
            expect(component.divForNormalGrid).toBe(true);
        }
    }));
    it('Popup Dialog for ADD should Send Values to Grid  onclick of Save button', async(() => {
        fixture.detectChanges();
        expect(component.gridData.length).toBe(0);
        component.showPopupDialog = false;
        component.ownershipItemForm = null;  // blank up the form to be added
        component.showAddOwnershipDialog();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getAddForm();
        component.ownershipForm = mockFormBuilder.setOwnershipForm();  // provide some test data.
        component.modalAction = 'ADD_ITEM';
        component.searchByGCINCIF('ABCD');
        component.onSearchGCIDCIFSelect('CFID_1 ABCD COMPANY OF INDIA');
        component.SubmitOwnershipForm(component.ownershipItemForm.value);
        expect(component.gridData.length).toBe(1);
        expect(component.argToastMessageObject.message).toEqual('A new record of ownership details has been successfully added.');
    }));
    it('Popup Dialog for UPDATE should Send UPDATED Values to Grid  onclick of UPDATE icon', async(() => {
        fixture.detectChanges();
        component.gridData = [];
        expect(component.gridData.length).toBe(0);
        component.showPopupDialog = false;
        component.ownershipItemForm = null;  // blank up the form to be added
        component.showAddOwnershipDialog();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getAddForm();
        component.ownershipForm = mockFormBuilder.setOwnershipForm(); // provide some test data.
        component.searchByGCINCIF(mockFormBuilder.getAddForm().controls['actualCFID'].value);
        component.onSearchGCIDCIFSelect(mockFormBuilder.getAddForm().controls['cifId'].value);
        component.SubmitOwnershipForm(component.ownershipItemForm.value);
        expect(component.gridData.length).toBe(1);
        const ownershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = mockFormBuilder.getAddForm().controls['actualCFID'].value;
        ownershipItemModel.idType = mockFormBuilder.getAddForm().controls['idType'].value;
        ownershipItemModel.name = mockFormBuilder.getAddForm().controls['name'].value;
        ownershipItemModel.collateralOwnerShipPcnt = mockFormBuilder.getAddForm().controls['collateralOwnerShipPcnt'].value;
        const helperUtil: Helper = new Helper;
        ownershipItemModel.collateralOwnerShipPcnt = helperUtil.getRandomValue(mockFormBuilder.getAddForm().controls['collateralOwnerShipPcnt'].value);
        component.showUpdateOwnershipDialog(ownershipItemModel, 0);   // pass the test ID set , and Row idex to be Updated
        setTimeout(() => {
            component.SubmitOwnershipForm(component.ownershipItemForm.value);
            expect(component.gridData[0]['collateralOwnerShipPcnt']).toEqual(ownershipItemModel.collateralOwnerShipPcnt);
            expect(component.argToastMessageObject.message).toEqual('A record of ownership details has been successfully updated.');
        }, 1000);
    }));
    it('Should remove row from grid on click of delete icon', async(() => {
        fixture.detectChanges();
        expect(component.gridData.length).toBe(0);
        component.showPopupDialog = false;
        component.ownershipItemForm = null;  // blank up the form to be added
        component.showAddOwnershipDialog();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getAddForm();
        component.ownershipForm = mockFormBuilder.setOwnershipForm();  // provide some test data.
        component.searchByGCINCIF(mockFormBuilder.getAddForm().controls['actualCFID'].value);
        component.onSearchGCIDCIFSelect(mockFormBuilder.getAddForm().controls['cifId'].value);
        component.SubmitOwnershipForm(component.ownershipItemForm.value);
        expect(component.ownershipGridDataForHtml.length).toBe(1);
        const testObj = new OwnershipItemModel();
        testObj.cifId = 'CFID_1';
        component.removeClickedSpecificDetailsItem({dataItem:testObj,rowIndex:0});
        const dlgPayload = ['yes'];
        component.confirmationFromYesNo(dlgPayload);
        expect(component.showYesNoPrompt).toBe(false);
        expect(component.ownershipGridDataForHtml.length).toBe(0);
        expect(component.argToastMessageObject.message).toEqual('A record of ownership details has been successfully deleted.');
    }));
    it('Should show no records component if there is no records from collateral service', async(() => {
        component.showSummaryGrid = false;
        component.setupComponent();
        expect(component.gridData.length).toBe(0);
        expect(component.divForNormalGrid).toBe(true);
        expect(component.noRecordsFlg).toBe(true);
    }));
    it('GCIN Search returns Complete GCIN Information for searchstring if it is greater than equal to 3 characters ', async(() => {
        const testVal = 'CFID_1';
        expect(testVal.length).toBeGreaterThanOrEqual(3);              // test string is equal or greater than 3
        component.searchByGCINCIF(testVal);
        expect(component.searchGCIDCIFData.length).toBeGreaterThan(0);   // Atleast 1 or more matches have come
    }));
    it('GCIN Search returns No Information for searchstring if it is less than 3 characters ', async(() => {
        const testVal = 'CF';
        expect(testVal.length).toBeLessThan(3);              // test string is equal or greater than 3
        component.searchByGCINCIF(testVal);
        expect(component.searchGCIDCIFData.length).toBe(0);   // No values have been picked
    }));
    it('on Select of onSearchGCIDCIFSelect returns Information for of matched  value', async(() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        const testVal1 = 'CFID_1';
        component.searchByGCINCIF(testVal1);
        const testVal2 = 'CFID_1 ABCD COMPANY OF INDIA';
        component.onSearchGCIDCIFSelect(testVal2);
        expect(component.selectedGCINItem[0]['ownershipCode']).toBe(testVal1);
        expect(component.selectedGCINItem[0]['ownershipName']).toBe(testVal2);
    }));
    it('Grid shows data what ever is brought from the sercice ', async(() => {
        fixture.detectChanges();
        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        const collateralOwnershipList: OwnerShipList[] = [];
        const collateralOwnershipDetail: OwnerShipList = new OwnerShipList;
        collateralOwnershipDetail.cifId = 'CFID_1';
        collateralOwnershipDetail.idType = 'COUNTERPARTY';
        collateralOwnershipDetail.name = 'ABCD COMPANY OF INDIA';
        collateralOwnershipList.push(collateralOwnershipDetail);
        collateral.ownershipDetails = collateralOwnershipList;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        component.setupComponent();
        expect(component.gridData.length).toBe(1);
    }));
    it('ownershipRemoveItem doesnot process out of range indexes relative to grid ', (() => {
        fixture.detectChanges();
        component.gridData.push(['Val1']);
        const testObj = new OwnershipItemModel();
        let testIndex: number = -1;
        expect(component.ownershipRemoveItem(testObj, testIndex)).toBeUndefined();
        testIndex = 100;
        expect(component.ownershipRemoveItem(testObj, testIndex)).toBeUndefined();
        component.gridData.pop();
        expect(component.ownershipRemoveItem(testObj, testIndex)).toBeUndefined();
    }));
    it('cleanseItemDescription   cleans  GCIN string  from description String ', (() => {
        fixture.detectChanges();
        const description = 'ABCD COMPANY OF INDIA (CFID_1)';
        const gcin = 'CFID_1';
        const cleansedValue = 'ABCD COMPANY OF INDIA';
        expect(component.cleanseItemDescription(description, gcin)).toBe(cleansedValue);
    }));
    it('cleanseItemDescription   doesnot alter description String if GCIN is absent ', (() => {
        fixture.detectChanges();
        const description = 'ABCD COMPANY OF INDIA (CFID_1)';
        const gcin = 'CFID_X';
        expect(component.cleanseItemDescription(description, gcin)).toBe(description);
    }));
    it('cleanseItemDescription   doesnot alter process undefined GCIN/DEScriptiopn  ', (() => {
        fixture.detectChanges();
        const description = undefined;
        const gcin = undefined;
        expect(component.cleanseItemDescription(description, gcin)).toBeUndefined();
    }));
    it('processFormItems function  Calls and  round off  functions for preocessing  perccentages in Griddata ', (() => {
        fixture.detectChanges();
        let ownershipItemModel: OwnershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = 'GCIN-1';
        ownershipItemModel.collateralOwnerShipPcnt = 59.001;
        component.gridData.push(ownershipItemModel);
        ownershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = 'GCIN-2';
        ownershipItemModel.collateralOwnerShipPcnt = 39.998;
        component.gridData.push(ownershipItemModel);
        spyOn(component, 'roundNumber');
        component.processFormItems();
        expect(component.roundNumber).toHaveBeenCalled();
    }));
    it('CheckFormValidity  function  validates the  Datapassed to it  ', (() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        component.modalAction = 'ADD_ITEM';
        const ownershipItemModel: OwnershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = 'CFID_1 ABCD COMPANY OF INDIA';
        ownershipItemModel.collateralOwnerShipPcnt = 91.999;
        component.searchByGCINCIF('CFID_1');
        component.onSearchGCIDCIFSelect('CFID_1 ABCD COMPANY OF INDIA');
        expect(component.checkFormValidity(ownershipItemModel)).toBeTruthy();
    }));
    it('CheckFormValidity  function  validates the Percentage to be within 100 to it  ', (() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        component.modalAction = 'ADD_ITEM';
        const ownershipItemModel: OwnershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = 'CFID_1 ABCD COMPANY OF INDIA';
        ownershipItemModel.collateralOwnerShipPcnt = 200;
        component.searchByGCINCIF('CFID_1');
        component.onSearchGCIDCIFSelect('CFID_1 ABCD COMPANY OF INDIA');
        expect(component.checkFormValidity(ownershipItemModel)).not.toBeTruthy();
        expect(component.exceed100LmitDivFlg).toBeTruthy();
    }));
    it('CheckFormValidity  function  validates the duplicty of the record  being added to grid', (() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        const ownershipItemModel1: OwnershipItemModel = new OwnershipItemModel();
        ownershipItemModel1.cifId = 'CFID_1';
        ownershipItemModel1.collateralOwnerShipPcnt = 8.001;
        component.ownershipGridDataForHtml.push(ownershipItemModel1);
        const ownershipItemModel: OwnershipItemModel = new OwnershipItemModel();
        ownershipItemModel.cifId = 'CFID_1 ABCD COMPANY OF INDIA';
        ownershipItemModel.collateralOwnerShipPcnt = 30;
        component.searchByGCINCIF('CFID_1');
        component.onSearchGCIDCIFSelect('CFID_1 ABCD COMPANY OF INDIA');
        component.modalAction = 'ADD_ITEM';
        ownershipItemModel.actualCFID = 'CFID_1';
        expect(component.checkFormValidity(ownershipItemModel)).not.toBeTruthy();
        expect(component.duplicateOwnershipGCINErrDivFlg).toBeTruthy();
    }));
    it('Add records link in no-records-compoenent bring up the Add ownership dialog', (() => {
        fixture.detectChanges();
        const e: Event = null;
        component.onLabelClicked(e);
        expect(component.ownershipItemForm).toBeTruthy();
    }));
    it('Should popup dialog false on click of close icon', (() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getBlankForm();
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    }));
    it('Should check validations for grid length', (() => {
        const c: AbstractControl = new FormControl;
        expect(OwnershipTotalPercentageValidator.getMessage(c)).toEqual('Make sure that total sum of ownership percentage should be 100.');
        expect(OwnershipTotalPercentageValidator.checkTotal(100)).toBe(true);
        expect(OwnershipTotalPercentageValidator.checkTotal(null)).toBe(false);
        expect(OwnershipTotalPercentageValidator.checkTotal(12)).toBe(false);
        const expectResult = {
            required: 'Make sure that total sum of ownership percentage should be 100.'
        };
        expect(OwnershipTotalPercentageValidator.required(new FormControl('123456'), '')).toEqual(expectResult);
    }));
    it('status message for ownership details update', async(() => {
        expect(component.gridData.length).toBe(0);
        component.showPopupDialog = false;
        component.ownershipItemForm = null;  // blank up the form to be added
        component.showAddOwnershipDialog();
        const mockFormBuilder = new MockFormBuilder();
        component.ownershipItemForm = mockFormBuilder.getAddForm();
        component.ownershipForm = mockFormBuilder.setOwnershipForm();  // provide some test data.
        component.modalAction = 'ADD_ITEM';
        component.searchByGCINCIF('ABCD');
        component.onSearchGCIDCIFSelect('CFID_1 ABCD COMPANY OF INDIA');
        component.SubmitOwnershipForm(component.ownershipItemForm.value);
        let colorStatus;
        component.collateralService.tabList.forEach(element => {
            if (element.id === 'ownership_tab') {
                colorStatus = element.fullfillmentStyle;
            }
        });
        expect(colorStatus).toBe(TabStatus.completed);
    }));
    it('ngOnchanges for collateralLoaded', () => {
        component.collateralLoaded = true;
        const changes: SimpleChanges | any = {
            collateralLoaded: true
        };
        spyOn(component, 'setupComponent');
        component.ngOnChanges(changes);
        expect(component.setupComponent).toHaveBeenCalled();
    });
});



