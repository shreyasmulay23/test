import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { OwnershipService } from './ownership.service';
import { OwnershipIdList } from './ownership.data-model';
import { OwnerShipList } from '../model/collateral';
import { CommonUtil } from 'app/common/utils/common.util';
import { ErrorResponse } from '../../shared/model/error-response.data';
import 'rxjs/Rx';
export class OwnershipItemModel extends OwnerShipList {
    actualCFID = '';
}
class TMockOwnershipService {
    getGCIDCIFData(data) {
        return Observable.of(OwnershipIdList);
    }
}
describe('OwnershipService', () => {
    let ownershipService: OwnershipService;
    let mockBackend: MockBackend;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                OwnershipService
            ],
            imports: [HttpModule]
        });
    });
    beforeEach(
        inject([OwnershipService, MockBackend], (service: OwnershipService, backend: MockBackend) => {
            ownershipService = service;
            mockBackend = backend;
        })
    );
    it('Ownership service should be defined', () => {
        expect(ownershipService).toBeDefined();
    });
    it('Should get response for addOwnership', fakeAsync(() => {
        const mockResponseBody = '';
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });
        const item: any = {
            cifId: 'cfid',
            name: 'name'
        };
        ownershipService.addOwnership(item).subscribe((response: Response) => {
            expect(response).toEqual('');
        });
    }));
    it('Should get response for getGCIDCIFData', fakeAsync(() => {
        const mockResponseBody = '';
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });
        const bodyData = { 'searchKeyword': 'GCIN' };
        ownershipService.getGCIDCIFData(bodyData).subscribe((response: Response) => {
            expect(response).toEqual('');
        });
    }));
    it('addOwnership service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockRespond(new Response(new ResponseOptions(ErrorResponse)));
                const item: any = {
                    cifId: 'cfid',
                    name: 'name'
                };
                spyOn(CommonUtil, 'errorResponseFunction').and.returnValue(Observable.of(ErrorResponse));
                ownershipService.addOwnership(item)
                    .subscribe((error) => {
                        expect(error.status).toEqual(ErrorResponse.status);
                    });
                ownershipService.getGCIDCIFData('xyzw')
                    .subscribe((error) => {
                        expect(error.status).toEqual(ErrorResponse.status);
                    });
            });
    }));
});

