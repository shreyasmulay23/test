export const OwnershipIdList = [
    {
        'description': '16R2A GCIN4NF CN002 (GC0001045990)',
        'gcin': 'GC0001045990',
        'type': 'COUNTERPARTY1',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN004 (GC0001045991)',
        'gcin': 'GC0001045991',
        'type': 'COUNTERPARTY2',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN006 (GC0001045992)',
        'gcin': 'GC0001045992',
        'type': 'COUNTERPARTY3',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN008 (GC0001045993)',
        'gcin': 'GC0001045993',
        'type': 'COUNTERPARTY4',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN010 (GC0001045995)',
        'gcin': 'GC0001045995',
        'type': 'COUNTERPARTY5',
        'typeDescription': 'COUNTERPARTY'
    }
];
