export class SummaryRowDetails {
    sumOfOwnershipPercentage: number;
    prefixCode: string;
}

export const OwnershipGrid = {
    'OWN': {
        'label': 'Document',
        'columns': [
            {
                'field': 'cifId',
                'title': 'Ownership ID',
                'width': '<6></6>00',
                'customClass': 'sub_item_text',
                'subItemName': 'name',
                'primary': true,
                'footerTemplate': 'Total Ownership Percentage'
            }, {
                'field': 'collateralOwnerShipPcnt',
                'format': '{0:c}',
                'title': 'Ownership Sharing (%)',
                'width': 200,
                'type': 'percent',
                'period': '%',
                'primary': true,
                'customClass': 'align-right',
                'footerTemplate': 'sumOfOwnershipPercentage'
            }
        ]
    }
};