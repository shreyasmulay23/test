import { AbstractControl } from '@angular/forms';
export class OwnershipTotalPercentageValidator {
    private static message = 'Make sure that total sum of ownership percentage should be 100.';

    static required(c: AbstractControl, typeGuarantee?: string) {
        return c.value ? OwnershipTotalPercentageValidator.checkTotal(c.value) ? null : {
            required: OwnershipTotalPercentageValidator.getMessage(c) // the custom message you wish to display
        } : {
            required: OwnershipTotalPercentageValidator.getMessage(c)          // previous value  -> ' cannot be null'
        };
    }

    static getMessage(c: AbstractControl): string {
        return this.message;
    }

    static checkTotal(val): boolean {
        if (val === 100) {
            return true;
        } else if (val === null) {
            return false;     // Make this true if not mandatory
        }
        return false;
    }
}

