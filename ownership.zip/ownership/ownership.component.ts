import { ChangeDetectorRef, Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { OwnershipService } from './ownership.service';
import { OwnerShipList } from '../model/collateral';
import { CollateralService } from '../collateral.service';
import { ErrorResponse } from '../../shared';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { PercentageValidator } from '../../common/custom-validators/custom-percentage-validator';
import { TabStatus } from 'app/common/models/TabStatus';
import { FormMaps } from '../model/formMaps.map';
import { ColumnSetting } from 'app/common/data-grid';
import { OwnershipGrid, SummaryRowDetails } from 'app/collateral/ownership/ownership-data-grid';
import { COLLATERAL_ITEM } from '../model/collaterals-config';

export class OwnershipItemModel extends OwnerShipList {
    actualCFID = '';
    source = '';
}
@Component({
    selector: 'collateral-ownership',
    templateUrl: './ownership.component.html',
    styleUrls: ['./ownership.component.scss']
})
export class OwnershipComponent implements OnInit {
    summaryRowDetails: SummaryRowDetails;
    showPopupDialog = false;
    rowIndex: number;
    divForNormalGrid: boolean = false;
    sumOfOwnershipPercentage: number = 0.0;
    noRecordsFlg: boolean = false;
    numberOfRecords: number;
    argToastMessageObject: any;
    counterPartyInvalid = false;
    percentageInvalid = false;
    duplicateOwnershipGCINErrDivFlg = false;
    exceed100LmitDivFlg = false;
    ownershipItemsList: OwnershipItemModel[] = [];
    toastsComponent: ToastsComponent = new ToastsComponent();
    public searchGCIDCIFData = [];
    tmpSelectedGCIN = '';
    gridData: any[];
    public ownershipGridDataForHtml: any[] = [];
    summarygrid: any = [];
    errMsg = false;
    errorMessage: string;
    showLoader = false;
    modalAction = '';
    disableGCINCIF = false;
    errorResponse: ErrorResponse = null;
    public selectedGCINItem: any;
    public dialogTitle: string;
    @Input() yesNoPromptForDelete: any;
    @Input() showAddOwnershipBtn = true;
    @Input() showSummaryGrid: boolean;
    @Input() ownershipForm: FormGroup;
    ownershipItemForm: FormGroup;
    previousPercentage = 0.0;
    showYesNoPrompt = false;
    ownershipObjToDelete: any;
    ownershipRowToDelete: number;
    public configForGridColumns: ColumnSetting[] = [];
    ownershipDeletePopupTitle: string = COLLATERAL_ITEM.ownership.remove.dialog_title;
    ownershipDeleteMessage: string = COLLATERAL_ITEM.ownership.remove.message;

    @Input() collateralLoaded = false;

    constructor(private _fb: FormBuilder, public ownershipService: OwnershipService,
                private cdRef: ChangeDetectorRef, public collateralService: CollateralService) {
    }

    // getRecentDetections(): void {
    // 	this.ownershipForm.valueChanges.subscribe(recent => {
    // 		this.cdRef.detectChanges();
    // 	});
    // }
    ngOnInit(): void {
        this.setupComponent();
        this.ownershipForm.valueChanges.subscribe(data => {
            this.onValueChanges(data);
        });
        this.getConfigurations();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['collateralLoaded'] && this.collateralLoaded) {
            if (changes['collateralLoaded']) {
                this.ngOnInit();
            }
        }
    }

    getConfigurations() {
        this.configForGridColumns = <ColumnSetting[]>JSON.parse(JSON.stringify(OwnershipGrid.OWN.columns));
    }

    onValueChanges(data: any) {
        this.updateErrorTabs();
    }

    private updateErrorTabs() {
        this.collateralService.createErrorTabs('ownership_tab');
    }

    findKeyFromMap(val?: string) {
        let k = '';
        let found = false;
        Object.keys(FormMaps.map).forEach(key => {
            if (!found) {
                if (val === FormMaps.map[key]) {
                    k = key;
                    found = true;
                }
            }
        });
        return k;
    }

    setupComponent() {
        this.customizeOwnershipGridForSummaryComp();
        if (this.collateralService.getCollateral().ownershipDetails) {
            this.gridData = this.collateralService.getCollateral().ownershipDetails;
            this.numberOfRecords = this.gridData.length;
            if (this.numberOfRecords > 0) {
                this.collateralService.setStatusOfComponent('ownership_tab', TabStatus.completed);
            }
            this.ownershipGridDataForHtml = this.collateralService.getCollateral().ownershipDetails.filter(Data => Data.__row_status !== 'deleted');
        } else {
            this.gridData = [];
        }
        this.summarygrid = this.gridData;
        this.ownershipItemsList = this.gridData;
        this.ownershipItemsList.forEach(function (item) {
            item.source = 'BACK_END';
        });
        this.processFormItems();
    }

    passOwnershipListToParent() {
        let tmpGrid = [];
        tmpGrid = this.ownershipItemsList;
        // remove the 	actualCFID  from  the list before passing
        for (const key in tmpGrid) {
            if (tmpGrid.hasOwnProperty(key)) {
                delete tmpGrid[key].actualCFID;
                delete tmpGrid[key].source;
            }
        }
        this.ownershipForm.controls['ownershipid'].setValue(tmpGrid);
    }

    cleanseItemDescription(description: string, gcin: string): string {
        if ((!description) && (!gcin)) {
            return;
        }
        if (description.search(gcin) < 0) {     // the gcin doesnot exist in description hence return.
            return description;
        }
        let cleanItem = description.replace(gcin, '');
        cleanItem = cleanItem.replace('()', '').trim();
        return cleanItem;
    }

    public searchByGCINCIF(searchValue: string) {
        this.searchGCIDCIFData = [];
        if (searchValue.length > 2) {
            this.ownershipService.getGCIDCIFData(searchValue).subscribe(data => {
                    if (data) {
                        this.searchGCIDCIFData = [];
                        this.searchGCIDCIFData = data.map(function (item) {
                            return ({
                                'ownershipCode': item.gcin,
                                'ownershipName': item.gcin + ' ' + this.cleanseItemDescription(item.description, item.gcin),
                                'ownershipType': item.type
                            });
                        }, this);
                    }
                },
                error => {
                    this.errMsg = true;
                    this.errorMessage = 'Oops! something went wrong.    ' + error._body;
                }
            );
        }
    }

    public showAddOwnershipDialog() {
        this.modalAction = 'ADD_ITEM';
        this.dialogTitle = 'Add Ownership Details';
        this.ownershipItemForm = this._fb.group({
            cifId: ['', [Validators.required]],
            idType: ['', [Validators.required]],
            collateralOwnerShipPcnt: ['', [PercentageValidator.percentageRequired]],
            name: ['', [Validators.required]],
            actualCFID: ['', [Validators.required]],
            ownershipRowStatus: [''],
            id: [''],
            _version: ['']
        });
        this.ownershipItemForm.valueChanges.subscribe(data => {
            this.percentageInvalid = false;
            this.exceed100LmitDivFlg = false;
        });
        this.showPopupDialog = true;
        this.disableGCINCIF = false;
        this.validationReset();
    }

    public showUpdateOwnershipDialog(argData: OwnershipItemModel, index: number) {
        this.searchByGCINCIF(argData.cifId);   // Make call to get the latest description for the GCIN
        setTimeout(() => {
            if (!(this.searchGCIDCIFData === undefined)) {
                this.selectedGCINItem = this.searchGCIDCIFData[0];
                const tmpDisplayCFID = this.searchGCIDCIFData[0]['ownershipName'];
                this.validationReset();
                this.rowIndex = index;
                this.modalAction = 'UPDATE_ITEM';
                this.dialogTitle = 'Edit Ownership Details';
                this.ownershipItemForm = this._fb.group({
                    cifId: [tmpDisplayCFID, [Validators.required]],
                    idType: [argData.idType, [Validators.required]],
                    collateralOwnerShipPcnt: [argData.collateralOwnerShipPcnt, [PercentageValidator.percentageRequired]],
                    name: [argData.name, [Validators.required]],
                    actualCFID: [argData.cifId, [Validators.required]],
                    ownershipRowStatus: [argData.__row_status],
                    id: [argData.id],
                    _version: [argData._version]
                });
                this.previousPercentage = argData.collateralOwnerShipPcnt;   // Will be used for validation of percentages sum
                this.showPopupDialog = true;
                this.disableGCINCIF = true;
            }
            this.ownershipItemForm.valueChanges.subscribe(data => {
                this.percentageInvalid = false;
                this.exceed100LmitDivFlg = false;
            });
        }, 1000);
    }

    closeEventFromPopupDialog(e: boolean): void {
        this.showPopupDialog = e;
        this.ownershipItemForm.reset();
    }

    editEventForRow(rowDetails) {
        const rowItem = rowDetails.dataItem;
        const rowIndex = rowDetails.rowIndex;
        this.showUpdateOwnershipDialog(rowItem, rowIndex);
    }

    getGridPercentageSum(): number {
        let gridSumOfOwnershipPercentage = 0.0;
        for (let i = 0; i < this.ownershipGridDataForHtml.length; i++) {
            gridSumOfOwnershipPercentage += parseFloat(this.ownershipGridDataForHtml[i]['collateralOwnerShipPcnt']);
        }
        gridSumOfOwnershipPercentage = this.roundNumber(gridSumOfOwnershipPercentage, 12);

        return gridSumOfOwnershipPercentage;
    }

    checkFormValidity(ownershipFormValue: OwnershipItemModel): boolean {
        let finalResult = true;
        // Check if there is Duplicate ownership ID in teh List  in case of an add_item
        if ((this.modalAction === 'ADD_ITEM') && (this.selectedGCINItem !== undefined)) {

            // check that cif value  has been correctly   populated from the  resposne Search results
            if (ownershipFormValue.cifId.toString() !== this.selectedGCINItem[0].ownershipName.toString()) {
                this.counterPartyInvalid = true;
                finalResult = (finalResult && false);
            } else {
                // check for Duplicity of GCINS
                const dataObj = this.ownershipGridDataForHtml.find(item => item.cifId.toString() === ownershipFormValue['actualCFID'].toString());
                if (dataObj === undefined) {
                    this.duplicateOwnershipGCINErrDivFlg = false;
                    this.counterPartyInvalid = false;
                    finalResult = (finalResult && true);
                } else {
                    this.counterPartyInvalid = true;
                    this.duplicateOwnershipGCINErrDivFlg = true;
                    finalResult = (finalResult && false);
                }
            }
        } else {
            if ((this.modalAction === 'UPDATE_ITEM') && (this.selectedGCINItem !== undefined)) {
                this.duplicateOwnershipGCINErrDivFlg = false;
                this.counterPartyInvalid = false;
                finalResult = (finalResult && true);
            } else {
                finalResult = (finalResult && false);
                this.counterPartyInvalid = true;
            }
        }
        // Check for the validity of the  Percentages entered.
        if ((ownershipFormValue['collateralOwnerShipPcnt'].toString().length === 0)) {
            this.percentageInvalid = true;
            finalResult = (finalResult && false);
        } else {
            const gridSumOfOwnershipPercentage: number = this.getGridPercentageSum();
            // Sum of Percentages  should be  within grange 0 -100 with 3 decimal places.
            let tmpSumPercentage = (Number.parseFloat(ownershipFormValue['collateralOwnerShipPcnt'].toString()) + gridSumOfOwnershipPercentage) - this.previousPercentage;
            tmpSumPercentage = this.roundNumber(tmpSumPercentage, 12);
            if (!((tmpSumPercentage <= 100) && (tmpSumPercentage >= 0))) {
                this.percentageInvalid = true;
                this.exceed100LmitDivFlg = true;
                finalResult = (finalResult && false);
            } else {
                this.percentageInvalid = false;
                finalResult = (finalResult && true);
            }
        }
        return finalResult;
    }

    SubmitOwnershipForm(ownershipFormValue: OwnershipItemModel): boolean {
        if (!this.checkFormValidity(ownershipFormValue)) {
            return false;
        }
        this.showPopupDialog = false;
        this.gridData = [];
        if (this.modalAction === 'UPDATE_ITEM') {
            this.ownershipItemsList.forEach(function (item) {
                if (item.cifId === ownershipFormValue.actualCFID) {
                    item.collateralOwnerShipPcnt = ownershipFormValue.collateralOwnerShipPcnt;
                    if (item.source === 'BACK_END') {
                        item.__row_status = 'modified';
                    } else {
                        item.__row_status = 'added';
                    }
                }
            });
            this.passOwnershipListToParent();
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                'A record of ownership details has been successfully updated.',
                '', '');
        }
        if (this.modalAction === 'ADD_ITEM') {

            // if Gcin pre exists in list set row-status to modified
            let gcinPreExsits = false;
            this.ownershipItemsList.forEach(function (item) {
                if ((item.cifId === ownershipFormValue.actualCFID) && (item.source === 'BACK_END')) {
                    item.__row_status = 'modified';
                    item._version = ownershipFormValue._version;
                    item.collateralOwnerShipPcnt = ownershipFormValue.collateralOwnerShipPcnt;
                    gcinPreExsits = true;
                }
            });
            // Add record only of the gcin is no there  in the list
            if (gcinPreExsits === false) {
                const ownershipItemModel = new OwnershipItemModel();
                ownershipItemModel.cifId = this.tmpSelectedGCIN;
                ownershipItemModel.name = ownershipFormValue.name;
                ownershipItemModel.idType = ownershipFormValue.idType;
                ownershipItemModel.collateralOwnerShipPcnt = ownershipFormValue.collateralOwnerShipPcnt;
                ownershipItemModel.__row_status = 'added';
                ownershipItemModel.id = 'ownership' + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5);
                ownershipFormValue._version = '';
                this.ownershipItemsList.push(ownershipItemModel);
                this.tmpSelectedGCIN = '';
                this.ownershipService.addOwnership(ownershipItemModel).subscribe(data => {
                }, error => {
                    this.errorResponse = <ErrorResponse>error;
                });
                this.passOwnershipListToParent();
                this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                    'A new record of ownership details has been successfully added.',
                    '', '');
                this.numberOfRecords = this.numberOfRecords + 1;
                this.collateralService.setStatusOfComponent('ownership_tab', TabStatus.completed);
            }
        }
        this.ownershipItemForm.reset();
        this.showPopupDialog = false;
        this.modalAction = '';
        this.gridData = this.ownershipItemsList;
        this.ownershipGridDataForHtml = [];
        this.ownershipGridDataForHtml = this.gridData.filter(Data => Data.__row_status !== 'deleted');
        this.processFormItems();
    }

    // TODO Add the testcases
    public removeClickedSpecificDetailsItem(data: any) {
        this.ownershipRemoveItem(data.dataItem,data.rowIndex);
    }

    // Delete Button click event emit
    public ownershipRemoveItem(dataItem: OwnershipItemModel, index: number) {
        if (!(this.gridData.length > 0)) {
            return;
        }
        if (!((index >= 0) && (index < this.gridData.length))) {
            return;
        }
        this.ownershipObjToDelete = this.ownershipItemsList.find(item => item.cifId === dataItem.cifId);
        this.ownershipRowToDelete = this.ownershipItemsList.indexOf(this.ownershipObjToDelete);
        this.showYesNoPrompt = true;
    }

    deleteOwnershipItem() {

        if (this.ownershipObjToDelete.source === 'BACK_END') {
            this.ownershipItemsList[this.ownershipRowToDelete].__row_status = 'deleted';
        } else {
            this.ownershipItemsList.splice(this.ownershipRowToDelete, 1);
        }
        this.gridData = this.ownershipItemsList;
        this.argToastMessageObject = this.toastsComponent
            .buildToastMessageObject('success',
                'A record of ownership details has been successfully deleted.',
                '', '');
        this.numberOfRecords = this.numberOfRecords - 1;
        if (this.numberOfRecords < 1) {
            this.collateralService.setStatusOfComponent('ownership_tab', TabStatus.touched);
        }
        this.passOwnershipListToParent();
        this.ownershipGridDataForHtml = [];
        this.ownershipGridDataForHtml = this.gridData.filter(Data => Data.__row_status !== 'deleted');
        this.processFormItems();
    }

    onSearchGCIDCIFSelect(e: any): void {
        this.duplicateOwnershipGCINErrDivFlg = false;    // reset valdiation flags
        this.counterPartyInvalid = true;
        if (e === undefined) {
            return;
        }
        const selectItem = this.searchGCIDCIFData.filter(
            function (data) {
                return data.ownershipName === e;
            }
        );
        if (selectItem.length === 0) {
            this.counterPartyInvalid = true;
            return;     // if no data found
        } else {
            this.counterPartyInvalid = false;
        }
        this.selectedGCINItem = selectItem;    //  selected item retained for later validation  in form save
        const cleansedName = this.cleanseItemDescription(selectItem[0]['ownershipName'], selectItem[0]['ownershipCode']);
        this.ownershipItemForm.controls['name'].setValue(cleansedName);
        this.ownershipItemForm.controls['idType'].setValue(selectItem[0]['ownershipType']);
        this.ownershipItemForm.controls['actualCFID'].setValue(selectItem[0]['ownershipCode']);
        this.tmpSelectedGCIN = selectItem[0]['ownershipCode'];
    }

    stopPropagation(e: Event) {
        e.preventDefault();
    }

    processFormItems() {
        // Check for no records Flag
        if (this.ownershipGridDataForHtml.length > 0) {
            this.noRecordsFlg = false;
        } else {
            this.noRecordsFlg = true;
        }
        // Reset Values
        this.sumOfOwnershipPercentage = 0.000;
        this.previousPercentage = 0.000;
        for (let i = 0; i < this.ownershipGridDataForHtml.length; i++) {
            this.sumOfOwnershipPercentage = this.sumOfOwnershipPercentage + parseFloat(this.ownershipGridDataForHtml[i]['collateralOwnerShipPcnt']);
        }
        this.sumOfOwnershipPercentage = this.roundNumber(this.sumOfOwnershipPercentage, 12);
        this.summaryRowDetails = new SummaryRowDetails();
        this.summaryRowDetails.sumOfOwnershipPercentage = this.sumOfOwnershipPercentage;
        this.summaryRowDetails.prefixCode = '%';
        if (this.sumOfOwnershipPercentage) {
            (<FormControl>this.ownershipForm.controls['totalPercentageSum']).setValue(this.sumOfOwnershipPercentage);
        } else {
            (<FormControl>this.ownershipForm.controls['totalPercentageSum']).setValue(null);
        }
    }

    roundNumber(number, decimals): number {
        const newnumber = Number(number + '').toFixed(parseInt(decimals, 10));
        return parseFloat(newnumber);
    }

    customizeOwnershipGridForSummaryComp() {
        if (this.showSummaryGrid) {
            this.divForNormalGrid = false;
        } else {
            this.divForNormalGrid = true;
        }
    }

    onLabelClicked(e: Event) {
        this.showAddOwnershipDialog();
    }

    validationReset() {
        this.counterPartyInvalid = false;
        this.percentageInvalid = false;
        this.duplicateOwnershipGCINErrDivFlg = false;
        this.exceed100LmitDivFlg = false;
    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.deleteOwnershipItem();
        }
    }
}
