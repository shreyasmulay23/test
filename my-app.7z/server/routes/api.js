
const arrayOfCountryData = [
  { 'id': 1, 'code': 'INDIA', 'description': 'India' },
  { 'id': 2, 'code': 'USA', 'description': 'United States of America' },
  { 'id': 3, 'code': 'UK', 'description': 'United Kingdom' },
  { 'id': 4, 'code': 'SINGAPORE', 'description': 'Singapore' },
  {
    'id': 5, 'code': 'HK', 'description': 'Hong Kong'
  }
];

module.exports = function (app) {

  app.post('/country/addData', function (req, res) {
    var autoGenId = 0;
    counterObj = arrayOfCountryData[arrayOfCountryData.length - 1];
    console.log(counterObj);
    autoGenId = counterObj.id + 1;
    var newObjToPush = {};
    newObjToPush.id = autoGenId;
    newObjToPush.code = req.body.code;
    newObjToPush.description = req.body.description;
    arrayOfCountryData.push(newObjToPush);
  });

  app.get('/country/getData', function (req, res) {
    res.send(arrayOfCountryData);
  });

  app.delete('/country/deleteData/:id', function (req, res) {
    console.log('ID', req.params.id);
    for (var i = 0; i < arrayOfCountryData.length; i++) {
      if (arrayOfCountryData[i].id == req.params.id) {
        console.log('clicked')
        arrayOfCountryData.splice(i, 1);
        console.log(arrayOfCountryData)
        break;
      }
    }

  });

}//Here module exports close
