import { Component, OnInit } from '@angular/core';
import { CountryService } from './country.service';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css'],
  providers: [CountryService]
})
export class CountryComponent implements OnInit {

  constructor(private _countryService: CountryService) { }

  countryData: any = [];
  // showData: boolean = true;
  ngOnInit() {
    this.getCountryData();
  }

  public getCountryData() {
    this._countryService.getCountryData('http://localhost:3000/country/getData').subscribe(
      response => {
        this.countryData = response;
      }, error => {

      }, () => {
        // this.showData = true;
      });
  }

  public addCountryData(code: string, description: string) {
    let dataToAdd = { code: '', description: '' };
    dataToAdd.code = code;
    dataToAdd.description = description;
    console.log('Data which getting sent is ===> ', dataToAdd)
    this._countryService.addCountryData('http://localhost:3000/country/addData', dataToAdd).subscribe(
      response => {
        this.countryData = response;
      }, error => {

      }, () => {
        
      });
  }

  public deleteCountryData(id:number) {
    this._countryService.deleteCountryData('http://localhost:3000/country/deleteData', id).subscribe(
      response => {
        this.countryData = response;
      }, error => {

      }, () => {
        
      });
  }

}
