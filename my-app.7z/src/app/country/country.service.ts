import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class CountryService {

  constructor(private _http: Http) { }

  public getCountryData(url: string): Observable<any> {
    return this._http.get(url).map(res => res.json())
  }

  public addCountryData(url: string, data:any): Observable<any> {
    return this._http.post(url, data).map(res => res.json());
  }

  public deleteCountryData(url: string, id:number) {
    return this._http.delete(url + '/' + id).map(res => res.json());
  }
}
